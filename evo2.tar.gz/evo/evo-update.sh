sudo apt-get update
sudo apt-get install -y git
sudo apt-get install -y automake autoconf pkg-config libcurl4-openssl-dev libjansson-dev libssl-dev libgmp-dev make g++
sudo apt-get install -y lib32z1-dev

#   1.超过64线程的机器不论win还是乌班图加上参数 
#      1 乌班图下超过64线程：加参数 --cpu-affinity 0,8  ,单路9654 在加参数 -t 190   完整实列： --cpu-affinity 0,8 -t 190
#      2.win10系统下超过64线程：加参数 --cpu-affinity 0  然后多开，直到任务管理器干满线程为止 
